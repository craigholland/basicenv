from core.config.baseconfig import BaseConfig

__all__ = [
    "BaseConfig"
]
