from dataclasses import dataclass


@dataclass
class MyDataClass:
    name: str
    age: int
